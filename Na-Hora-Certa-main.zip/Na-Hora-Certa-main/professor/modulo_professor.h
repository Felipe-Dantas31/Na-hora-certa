char tela_menu_professor(void);
void tela_cadastrar_professor(void);
void tela_pesquisar_professor(void);
void tela_atualizar_professor(void);
void tela_excluir_professor(void);