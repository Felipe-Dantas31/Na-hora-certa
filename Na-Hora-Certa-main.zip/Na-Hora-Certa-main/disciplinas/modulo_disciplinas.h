char tela_menu_disciplina(void);
void tela_cadastrar_disciplina(void);
void tela_pesquisar_disciplina(void);
void tela_atualizar_disciplina(void);
void tela_excluir_disciplina(void);