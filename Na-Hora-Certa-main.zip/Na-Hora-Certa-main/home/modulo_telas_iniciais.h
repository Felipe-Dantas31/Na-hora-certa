void cabecalho_principal(void);
void cabecalho_secundario(void);
char tela_menu_principal(void);
void tela_sobre(void);
void tela_equipe(void);
void msg_escolha_invalida(void);
void msg_deu_certo(void);
void tela_login(void);