char tela_menu_salas(void);
void tela_cadastrar_salas(void);
void tela_pesquisar_salas(void);
void tela_atualizar_salas(void);
void tela_excluir_salas(void);