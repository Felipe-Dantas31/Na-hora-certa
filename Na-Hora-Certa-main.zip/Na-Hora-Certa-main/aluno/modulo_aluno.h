char tela_menu_aluno(void);
void tela_cadastrar_aluno(void);
void tela_pesquisar_aluno(void);
void tela_atualizar_aluno(void);
void tela_excluir_aluno(void);